extends Control
## إله الخلق (OmniForge) - لعبة خلق وحروب آلهة بالعربية

const SAVE_PATH := "user://omniforge_v2.json"
const LIFE := ["human", "animal", "plant", "fish"]

const ITEMS := {
	"universe": {"n": "كون", "p": 500.0},
	"galaxy": {"n": "مجرة", "p": 200.0},
	"solar": {"n": "نظام شمسي", "p": 80.0},
	"star": {"n": "نجم", "p": 40.0},
	"planet": {"n": "كوكب", "p": 25.0},
	"blackhole": {"n": "ثقب أسود", "p": 120.0},
	"human": {"n": "إنسان", "p": 10.0},
	"animal": {"n": "حيوان", "p": 6.0},
	"plant": {"n": "نبات", "p": 3.0},
	"fish": {"n": "سمكة", "p": 4.0},
	"water": {"n": "ماء", "p": 2.0},
	"earth": {"n": "أرض", "p": 3.0},
	"fire": {"n": "نار", "p": 5.0},
	"air": {"n": "هواء", "p": 2.0},
	"light": {"n": "نور", "p": 8.0},
}

const RAD := {
	"universe": 220.0, "galaxy": 120.0, "solar": 80.0, "star": 36.0, "planet": 34.0,
	"blackhole": 46.0, "human": 18.0, "animal": 20.0, "plant": 18.0, "fish": 18.0,
	"water": 16.0, "earth": 20.0, "fire": 20.0, "air": 20.0, "light": 22.0,
	"minion": 22.0,
}

const CATS := [
	{"n": "الكون", "k": ["universe", "galaxy", "solar", "star", "planet", "blackhole"]},
	{"n": "الحياة", "k": ["human", "animal", "plant", "fish"]},
	{"n": "العناصر", "k": ["water", "earth", "fire", "air", "light"]},
]

const SKILLS := [
	{"id": "create", "n": "قوة الخلق", "d": "تزيد قوة كل ما تخلقه 15% لكل مستوى"},
	{"id": "wrath", "n": "الغضب الإلهي", "d": "تزيد ضرر ضرباتك في المبارزة 12% لكل مستوى"},
	{"id": "shield", "n": "درع الأكوان", "d": "تقلل الضرر الذي تتلقاه 8% لكل مستوى"},
	{"id": "wisdom", "n": "حكمة الخلود", "d": "تقوّي الشفاء وتزيد الطاقة المستعادة"},
]

const GOD_DEFS := [
	{"n": "الحارس الأخضر", "kind": "verdant", "col": "#55e68a", "base": 600.0, "desc": "حكيم يداوي جراحه ويطيل المعركة"},
	{"n": "طاغية النجوم", "kind": "tyrant", "col": "#ff8a3d", "base": 1100.0, "desc": "عدواني يضرب بقوة نجمية مدمرة"},
	{"n": "سيد الفراغ", "kind": "void", "col": "#b46bff", "base": 1900.0, "desc": "ماكر يمتص طاقتك ويشفي نفسه"},
]

# ---------- حالة اللعبة ----------
var data: Dictionary = {}
var ents: Array = []
var gods: Array = []
var screen := "menu"
var tool := "move"
var cat_idx := 0
var cam := Vector2.ZERO
var zoom := 0.8
var place_scale := 1.0
var tm := 0.0
var parts: Array = []
var pops: Array = []
var stars: Array = []
var fnt: Font
var sfx := {}
var sfx_players: Array = []
var sfx_i := 0
var music: AudioStreamPlayer
var neb_col := Color(0.4, 0.2, 0.9)

# واجهة
var ui := {}
var lbl_power: Label
var xp_bar: ProgressBar
var lbl_hint: Label
var pal_box: HBoxContainer
var toast_lbl: Label
var tab_btns: Array = []
var skills_vb: VBoxContainer
var gods_vb: VBoxContainer
var res_lbl: Label
var war_lbl: Label
var duel_log: Label
var duel_btns: Array = []

# إدخال
var dragging := false
var drag_ent := -1
var moved := false
var press_pos := Vector2.ZERO

# حرب العوالم
var units: Array = []
var war_god := -1
var war_t := 0.0
var war_over := false
var war_won := false
var war_speed := 1.0
var war_end_t := 0.0
var fp := 1.0
var fg := 1.0

# مبارزة
var dp := 100.0
var dpm := 100.0
var dg := 100.0
var dgm := 100.0
var en := 50.0
var g_en := 40.0
var p_shield := false
var g_shield := false
var turn := "player"
var log_lines: Array = []
var shake_p := 0.0
var shake_g := 0.0


# ============================================================
#  عنصر رسم/لمس بسيط
# ============================================================
class Proxy extends Control:
	signal tapped
	var cb: Callable
	var press_at := Vector2.ZERO

	func _ready() -> void:
		clip_contents = true

	func _draw() -> void:
		if cb.is_valid():
			cb.call(self)

	func _process(_d: float) -> void:
		if is_visible_in_tree():
			queue_redraw()

	func _gui_input(ev: InputEvent) -> void:
		if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
			if ev.pressed:
				press_at = ev.position
			else:
				if ev.position.distance_to(press_at) < 25.0:
					tapped.emit()


# ============================================================
#  البدء
# ============================================================
func _ready() -> void:
	randomize()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	setup_font()
	setup_theme()
	make_stars()
	setup_audio()
	build_ui()
	data = default_data()
	ents = data["ents"]
	gods = data["gods"]
	go("menu")
	get_tree().create_timer(0.4).timeout.connect(start_music)


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if screen != "menu":
			save_game()


func setup_font() -> void:
	if ResourceLoader.exists("res://font.ttf"):
		fnt = load("res://font.ttf")
	else:
		var sf := SystemFont.new()
		sf.font_names = PackedStringArray(["Noto Sans Arabic", "Noto Naskh Arabic", "Roboto", "sans-serif"])
		fnt = sf


func mk_style(c: Color, r := 22, border := Color(1, 1, 1, 0.14)) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(r)
	s.border_color = border
	s.set_border_width_all(2)
	s.content_margin_left = 16
	s.content_margin_right = 16
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s


func setup_theme() -> void:
	var th := Theme.new()
	th.default_font = fnt
	th.default_font_size = 36
	th.set_stylebox("normal", "Button", mk_style(Color(0.16, 0.12, 0.38, 0.96)))
	th.set_stylebox("hover", "Button", mk_style(Color(0.22, 0.17, 0.5, 0.96)))
	th.set_stylebox("pressed", "Button", mk_style(Color(0.3, 0.22, 0.65, 0.96)))
	th.set_stylebox("disabled", "Button", mk_style(Color(0.1, 0.1, 0.18, 0.8)))
	th.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	th.set_stylebox("panel", "PanelContainer", mk_style(Color(0.04, 0.03, 0.15, 0.93), 0, Color(0.5, 0.4, 1, 0.25)))
	th.set_color("font_color", "Button", Color.WHITE)
	th.set_color("font_hover_color", "Button", Color.WHITE)
	th.set_color("font_pressed_color", "Button", Color.WHITE)
	th.set_color("font_disabled_color", "Button", Color(0.55, 0.55, 0.65))
	theme = th


func make_stars() -> void:
	for i in 150:
		stars.append(Vector3(randf(), randf(), randf_range(0.1, 1.0)))


# ============================================================
#  الصوت (يُولَّد بالكود)
# ============================================================
func mk_wav(samples: PackedFloat32Array, rate: int, loop := false) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in samples.size():
		bytes.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = samples.size()
	return w


func tone(f0: float, f1: float, dur: float, vol: float, noise := 0.0) -> AudioStreamWAV:
	var rate := 22050
	var n := int(dur * rate)
	var s := PackedFloat32Array()
	s.resize(n)
	var ph := 0.0
	for i in n:
		var u := float(i) / float(n)
		var f := lerpf(f0, f1, u)
		ph += TAU * f / float(rate)
		var env := (1.0 - u) * (1.0 - u)
		if u < 0.02:
			env *= u / 0.02
		s[i] = (sin(ph) + noise * randf_range(-1.0, 1.0)) * env * vol
	return mk_wav(s, rate)


func setup_audio() -> void:
	sfx["click"] = tone(660.0, 880.0, 0.08, 0.35)
	sfx["place"] = tone(300.0, 900.0, 0.25, 0.4)
	sfx["erase"] = tone(400.0, 120.0, 0.2, 0.35, 0.3)
	sfx["hit"] = tone(180.0, 60.0, 0.18, 0.5, 0.5)
	sfx["big"] = tone(120.0, 40.0, 0.5, 0.6, 0.6)
	sfx["win"] = tone(400.0, 1200.0, 0.8, 0.4)
	sfx["lose"] = tone(300.0, 80.0, 0.9, 0.4)
	sfx["heal"] = tone(500.0, 1000.0, 0.4, 0.3)
	for i in 4:
		var p := AudioStreamPlayer.new()
		add_child(p)
		sfx_players.append(p)
	music = AudioStreamPlayer.new()
	music.volume_db = -13.0
	add_child(music)


func play(n: String) -> void:
	if not sfx.has(n):
		return
	var p: AudioStreamPlayer = sfx_players[sfx_i % 4]
	sfx_i += 1
	p.stream = sfx[n]
	p.play()


func start_music() -> void:
	var rate := 8000
	var secs := 16
	var n := rate * secs
	var s := PackedFloat32Array()
	s.resize(n)
	var chords := [
		[110.0, 165.0, 220.0, 330.0],
		[87.5, 130.5, 175.0, 262.0],
		[98.0, 147.0, 196.0, 294.0],
		[110.0, 165.0, 220.0, 277.0],
	]
	for i in n:
		var t := float(i) / float(rate)
		var chi := int(t / 4.0) % 4
		var u := fmod(t, 4.0) / 4.0
		var env := sin(PI * u)
		env *= env
		var v := 0.0
		var ch: Array = chords[chi]
		for j in 4:
			var f: float = ch[j]
			var amp: float = 0.5 if j < 2 else 0.3
			v += sin(TAU * f * t) * amp
		v *= env * 0.22
		var pt := fmod(t, 2.0)
		var pf: float = 660.0 if (int(t / 2.0) % 2) == 0 else 880.0
		v += sin(TAU * pf * t) * exp(-pt * 3.0) * 0.08
		s[i] = v
	music.stream = mk_wav(s, rate, true)
	music.play()


# ============================================================
#  البيانات والحفظ
# ============================================================
func make_god(i: int, tier: int) -> Dictionary:
	var df: Dictionary = GOD_DEFS[i % 3]
	var pw: float = float(df["base"]) * pow(1.6, float(tier))
	var nm: String = df["n"]
	if tier > 0:
		nm += " (الجيل %d)" % (tier + 1)
	var pool := ["planet", "star", "human", "animal", "plant", "fish", "water", "earth", "fire", "air", "light", "galaxy", "solar", "blackhole", "universe"]
	var list: Array = []
	var cnt := clampi(int(pw / 55.0), 10, 45)
	for j in cnt:
		var k: String
		if randf() < 0.8:
			k = pool[randi() % 11]
		else:
			k = pool[11 + randi() % 4]
		var a := randf() * TAU
		var d := sqrt(randf()) * (300.0 + cnt * 18.0)
		list.append({"k": k, "x": cos(a) * d, "y": sin(a) * d, "s": randf_range(0.7, 1.6), "seed": randf()})
	return {"i": i % 3, "n": nm, "kind": df["kind"], "col": df["col"], "desc": df["desc"], "power": pw, "ents": list}


func default_data() -> Dictionary:
	var starter: Array = [
		{"k": "star", "x": -380.0, "y": -200.0, "s": 1.3, "seed": 0.31},
		{"k": "planet", "x": 0.0, "y": 0.0, "s": 1.3, "seed": 0.62},
		{"k": "human", "x": 60.0, "y": 70.0, "s": 1.0, "seed": 0.15},
		{"k": "plant", "x": -70.0, "y": 60.0, "s": 1.0, "seed": 0.77},
		{"k": "fish", "x": 150.0, "y": -40.0, "s": 1.0, "seed": 0.44},
	]
	return {
		"level": 1, "xp": 0, "points": 0, "bonus": 0.0, "wins": 0,
		"skills": {"create": 0, "wrath": 0, "shield": 0, "wisdom": 0},
		"ents": starter,
		"gods": [make_god(0, 0), make_god(1, 0), make_god(2, 0)],
	}


func save_game() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))


func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var txt := FileAccess.get_file_as_string(SAVE_PATH)
	var j = JSON.parse_string(txt)
	if j is Dictionary and j.has("ents") and j.has("gods") and j.has("skills"):
		data = j
		for k in ["level", "xp", "points", "wins"]:
			data[k] = int(data.get(k, 0))
		data["level"] = maxi(1, int(data["level"]))
		data["bonus"] = float(data.get("bonus", 0.0))
		for sk in ["create", "wrath", "shield", "wisdom"]:
			data["skills"][sk] = int(data["skills"].get(sk, 0))
		ents = data["ents"]
		gods = data["gods"]
		return true
	return false


func skill(id: String) -> int:
	return int(data["skills"][id])


func xp_need() -> int:
	return 60 + 40 * int(data["level"])


func add_xp(n: int) -> void:
	data["xp"] = int(data["xp"]) + n
	while int(data["xp"]) >= xp_need():
		data["xp"] = int(data["xp"]) - xp_need()
		data["level"] = int(data["level"]) + 1
		data["points"] = int(data["points"]) + 1
		toast("ارتقيت إلى المستوى %d  |  نقطة مهارة جديدة" % int(data["level"]))
		play("win")


func player_power() -> float:
	var s: float = 50.0 + float(data["level"]) * 20.0 + float(data["bonus"])
	for e in ents:
		var k: String = e["k"]
		var p: float = ITEMS[k]["p"]
		s += p * sqrt(float(e["s"]))
	return s * (1.0 + 0.15 * float(skill("create")))


func count_life(arr: Array) -> int:
	var c := 0
	for e in arr:
		if LIFE.has(e["k"]):
			c += 1
	return c


func world_center() -> Vector2:
	if ents.is_empty():
		return Vector2.ZERO
	var s := Vector2.ZERO
	for e in ents:
		s += Vector2(e["x"], e["y"])
	return s / float(ents.size())


func sort_ents() -> void:
	ents.sort_custom(func(a, b): return float(RAD[a["k"]]) * float(a["s"]) > float(RAD[b["k"]]) * float(b["s"]))


# ============================================================
#  بناء الواجهة
# ============================================================
func full(c: Control) -> void:
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func place(c: Control, al: float, at: float, ar: float, ab: float, ol := 0.0, ot := 0.0, or_ := 0.0, ob := 0.0) -> void:
	c.anchor_left = al
	c.anchor_top = at
	c.anchor_right = ar
	c.anchor_bottom = ab
	c.offset_left = ol
	c.offset_top = ot
	c.offset_right = or_
	c.offset_bottom = ob


func clear_node(n: Node) -> void:
	for c in n.get_children():
		n.remove_child(c)
		c.queue_free()


func on_btn(cb: Callable) -> void:
	play("click")
	cb.call()


func btn(text: String, cb: Callable, col := Color(0.2, 0.15, 0.5), fs := 36) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", fs)
	b.add_theme_stylebox_override("normal", mk_style(col))
	b.add_theme_stylebox_override("hover", mk_style(col.lightened(0.12)))
	b.add_theme_stylebox_override("pressed", mk_style(col.lightened(0.25)))
	b.custom_minimum_size = Vector2(0, 84)
	b.pressed.connect(on_btn.bind(cb))
	return b


func lbl(text: String, fs := 36, col := Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", fs)
	l.add_theme_color_override("font_color", col)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


func make_ui_root(name_id: String, mouse_ignore := true) -> Control:
	var c := Control.new()
	full(c)
	if mouse_ignore:
		c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(c)
	ui[name_id] = c
	return c


func make_overlay(name_id: String, l: float, t: float, r: float, b: float) -> VBoxContainer:
	var o := make_ui_root(name_id, false)
	var dim := ColorRect.new()
	full(dim)
	dim.color = Color(0, 0, 0, 0.68)
	o.add_child(dim)
	var pc := PanelContainer.new()
	o.add_child(pc)
	place(pc, l, t, r, b)
	pc.add_theme_stylebox_override("panel", mk_style(Color(0.06, 0.05, 0.2, 0.99), 28, Color(0.6, 0.5, 1, 0.5)))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	pc.add_child(vb)
	return vb


func build_ui() -> void:
	# ----- القائمة -----
	var m := make_ui_root("menu")
	var mv := VBoxContainer.new()
	m.add_child(mv)
	place(mv, 0.1, 0.64, 0.9, 0.64)
	mv.add_theme_constant_override("separation", 26)
	var b1 := btn("متابعة الخلق", continue_game, Color(0.3, 0.2, 0.75), 52)
	b1.custom_minimum_size = Vector2(0, 130)
	mv.add_child(b1)
	var b2 := btn("عالم جديد", new_game, Color(0.15, 0.12, 0.4), 44)
	b2.custom_minimum_size = Vector2(0, 110)
	mv.add_child(b2)

	# ----- العالم -----
	var w := make_ui_root("world")
	var top := PanelContainer.new()
	w.add_child(top)
	place(top, 0, 0, 1, 0, 0, 0, 0, 150)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	top.add_child(hb)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(info)
	lbl_power = lbl("", 32)
	info.add_child(lbl_power)
	xp_bar = ProgressBar.new()
	xp_bar.show_percentage = false
	xp_bar.custom_minimum_size = Vector2(0, 22)
	xp_bar.add_theme_stylebox_override("fill", mk_style(Color(0.5, 0.85, 1.0), 10, Color(0, 0, 0, 0)))
	xp_bar.add_theme_stylebox_override("background", mk_style(Color(0.1, 0.1, 0.25), 10, Color(0, 0, 0, 0)))
	info.add_child(xp_bar)
	hb.add_child(btn("حرب العوالم", open_gods, Color(0.7, 0.15, 0.2), 30))
	hb.add_child(btn("المهارات", open_skills, Color(0.25, 0.2, 0.7), 30))

	var bot := PanelContainer.new()
	w.add_child(bot)
	place(bot, 0, 1, 1, 1, 0, -440, 0, 0)
	var bv := VBoxContainer.new()
	bv.add_theme_constant_override("separation", 8)
	bot.add_child(bv)
	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	bv.add_child(tabs)
	for i in CATS.size():
		var tb := btn(CATS[i]["n"], select_cat.bind(i), Color(0.2, 0.15, 0.5), 30)
		tb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		tb.custom_minimum_size = Vector2(0, 76)
		tabs.add_child(tb)
		tab_btns.append(tb)
	var mv_b := btn("تحريك", select_tool.bind("move"), Color(0.1, 0.4, 0.45), 30)
	mv_b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mv_b.custom_minimum_size = Vector2(0, 76)
	tabs.add_child(mv_b)
	tab_btns.append(mv_b)
	var er_b := btn("إزالة", select_tool.bind("erase"), Color(0.5, 0.15, 0.2), 30)
	er_b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	er_b.custom_minimum_size = Vector2(0, 76)
	tabs.add_child(er_b)
	tab_btns.append(er_b)

	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(0, 200)
	sc.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	bv.add_child(sc)
	pal_box = HBoxContainer.new()
	pal_box.add_theme_constant_override("separation", 10)
	sc.add_child(pal_box)

	var hr := HBoxContainer.new()
	hr.add_theme_constant_override("separation", 10)
	bv.add_child(hr)
	var sm := btn("−", change_size.bind(-0.25), Color(0.2, 0.15, 0.5), 36)
	sm.custom_minimum_size = Vector2(110, 70)
	hr.add_child(sm)
	lbl_hint = lbl("", 28, Color(0.8, 0.85, 1))
	lbl_hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lbl_hint.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hr.add_child(lbl_hint)
	var sp := btn("+", change_size.bind(0.25), Color(0.2, 0.15, 0.5), 36)
	sp.custom_minimum_size = Vector2(110, 70)
	hr.add_child(sp)

	var zi := btn("+", zoom_by.bind(1.25), Color(0.1, 0.1, 0.35), 44)
	w.add_child(zi)
	place(zi, 1, 0, 1, 0, -120, 170, -20, 270)
	var zo := btn("−", zoom_by.bind(0.8), Color(0.1, 0.1, 0.35), 44)
	w.add_child(zo)
	place(zo, 1, 0, 1, 0, -120, 285, -20, 385)

	# ----- الحرب -----
	var wr := make_ui_root("war")
	war_lbl = lbl("", 38, Color(1, 0.9, 0.7))
	wr.add_child(war_lbl)
	place(war_lbl, 0, 0, 1, 0, 0, 40, 0, 140)
	var wb := HBoxContainer.new()
	wb.add_theme_constant_override("separation", 20)
	wr.add_child(wb)
	place(wb, 0.06, 1, 0.94, 1, 0, -170, 0, -50)
	var spd := btn("تسريع", toggle_speed, Color(0.25, 0.2, 0.7), 36)
	spd.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wb.add_child(spd)
	var ret := btn("انسحاب", retreat, Color(0.5, 0.15, 0.2), 36)
	ret.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wb.add_child(ret)

	# ----- المبارزة -----
	var du := make_ui_root("duel")
	duel_log = lbl("", 32, Color(1, 0.95, 0.8))
	duel_log.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	du.add_child(duel_log)
	place(duel_log, 0.04, 1, 0.96, 1, 0, -520, 0, -380)
	var dg_grid := GridContainer.new()
	dg_grid.columns = 2
	dg_grid.add_theme_constant_override("h_separation", 16)
	dg_grid.add_theme_constant_override("v_separation", 16)
	du.add_child(dg_grid)
	place(dg_grid, 0.04, 1, 0.96, 1, 0, -360, 0, -40)
	var defs := [
		["ضربة كونية", "atk", Color(0.7, 0.2, 0.25)],
		["انفجار نجمي (40)", "big", Color(0.8, 0.4, 0.1)],
		["درع إلهي", "shield", Color(0.15, 0.4, 0.75)],
		["شفاء (30)", "heal", Color(0.15, 0.55, 0.35)],
	]
	for d in defs:
		var db := btn(d[0], p_act.bind(d[1]), d[2], 34)
		db.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		db.custom_minimum_size = Vector2(0, 150)
		dg_grid.add_child(db)
		duel_btns.append(db)

	# ----- المهارات -----
	skills_vb = make_overlay("skills", 0.04, 0.14, 0.96, 0.86)
	# ----- الآلهة -----
	gods_vb = make_overlay("gods", 0.03, 0.08, 0.97, 0.92)
	# ----- النتيجة -----
	var rv := make_overlay("result", 0.08, 0.28, 0.92, 0.72)
	res_lbl = lbl("", 40)
	res_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	res_lbl.custom_minimum_size = Vector2(700, 300)
	res_lbl.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rv.add_child(res_lbl)
	rv.add_child(btn("متابعة", close_result, Color(0.3, 0.2, 0.75), 44))

	# ----- رسالة عائمة -----
	toast_lbl = lbl("", 34, Color(1, 0.95, 0.7))
	toast_lbl.add_theme_stylebox_override("normal", mk_style(Color(0.05, 0.03, 0.2, 0.92), 20, Color(1, 0.9, 0.5, 0.5)))
	add_child(toast_lbl)
	place(toast_lbl, 0.1, 0, 0.9, 0, 0, 165, 0, 165)
	toast_lbl.modulate.a = 0.0

	rebuild_palette()


func toast(msg: String) -> void:
	toast_lbl.text = msg
	toast_lbl.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_interval(1.6)
	tw.tween_property(toast_lbl, "modulate:a", 0.0, 0.6)


func go(s: String) -> void:
	screen = s
	for k in ["menu", "world", "war", "duel"]:
		ui[k].visible = (k == s)
	for k in ["skills", "gods", "result"]:
		ui[k].visible = false
	match s:
		"menu", "world":
			neb_col = Color(0.4, 0.2, 0.9)
		_:
			if war_god >= 0 and war_god < gods.size():
				neb_col = Color.html(str(gods[war_god]["col"]))
	if s == "world":
		refresh()
	queue_redraw()


func refresh() -> void:
	var pw := player_power()
	lbl_power.text = "المستوى %d   |   القوة %d" % [int(data["level"]), int(pw)]
	xp_bar.max_value = float(xp_need())
	xp_bar.value = float(int(data["xp"]))
	match tool:
		"move":
			lbl_hint.text = "اسحب لتحريك العالم أو الأجرام"
		"erase":
			lbl_hint.text = "المس أي شيء لإزالته"
		_:
			var nm: String = ITEMS[tool]["n"]
			lbl_hint.text = "المس الفضاء لخلق: %s  (الحجم %.2f)" % [nm, place_scale]
	for i in tab_btns.size():
		var active := false
		if i < CATS.size():
			active = (i == cat_idx)
		elif i == CATS.size():
			active = (tool == "move")
		else:
			active = (tool == "erase")
		tab_btns[i].modulate = Color(1, 1, 1) if active else Color(0.65, 0.65, 0.8)


func select_cat(i: int) -> void:
	cat_idx = i
	rebuild_palette()
	refresh()


func select_tool(k: String) -> void:
	tool = k
	refresh()


func change_size(d: float) -> void:
	place_scale = clampf(place_scale + d, 0.25, 4.0)
	refresh()


func zoom_by(f: float) -> void:
	zoom = clampf(zoom * f, 0.12, 3.0)


func rebuild_palette() -> void:
	clear_node(pal_box)
	var keys: Array = CATS[cat_idx]["k"]
	for k in keys:
		var key: String = k
		var px := Proxy.new()
		px.custom_minimum_size = Vector2(150, 190)
		px.mouse_filter = Control.MOUSE_FILTER_PASS
		px.cb = draw_icon.bind(key)
		px.tapped.connect(pick_item.bind(key))
		pal_box.add_child(px)


func pick_item(k: String) -> void:
	tool = k
	play("click")
	refresh()


func draw_icon(ci: Control, k: String) -> void:
	var sel := (tool == k)
	var bg: Color = Color(0.25, 0.2, 0.6, 0.95) if sel else Color(0.1, 0.08, 0.28, 0.95)
	ci.draw_rect(Rect2(Vector2.ZERO, ci.size), bg)
	ci.draw_rect(Rect2(Vector2.ZERO, ci.size), Color(1, 0.9, 0.5, 0.9) if sel else Color(1, 1, 1, 0.12), false, 3.0)
	var fit: float = 34.0 / float(RAD[k])
	draw_ent(ci, k, Vector2(ci.size.x * 0.5, 80.0), fit, tm, 0.37)
	var nm: String = ITEMS[k]["n"]
	ci.draw_string(fnt, Vector2(0, 168), nm, HORIZONTAL_ALIGNMENT_CENTER, ci.size.x, 30, Color.WHITE)


# ============================================================
#  القوائم: المهارات والآلهة والنتيجة
# ============================================================
func open_skills() -> void:
	ui["skills"].visible = true
	rebuild_skills()


func rebuild_skills() -> void:
	clear_node(skills_vb)
	skills_vb.add_child(lbl("شجرة المهارات", 48, Color(1, 0.9, 0.6)))
	skills_vb.add_child(lbl("نقاط المهارة: %d" % int(data["points"]), 38, Color(0.7, 0.9, 1)))
	for s in SKILLS:
		var id: String = s["id"]
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		skills_vb.add_child(row)
		var col := VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(col)
		var t := lbl("%s  (%d/5)" % [String(s["n"]), skill(id)], 38, Color(1, 0.9, 0.6))
		col.add_child(t)
		var d := lbl(String(s["d"]), 28, Color(0.8, 0.85, 1))
		d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		d.custom_minimum_size = Vector2(200, 0)
		col.add_child(d)
		var ub := btn("ترقية", upgrade.bind(id), Color(0.2, 0.5, 0.3), 32)
		ub.custom_minimum_size = Vector2(190, 90)
		ub.disabled = (skill(id) >= 5 or int(data["points"]) < 1)
		row.add_child(ub)
	var sp := Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	skills_vb.add_child(sp)
	skills_vb.add_child(btn("العودة للقائمة الرئيسية", to_menu, Color(0.3, 0.15, 0.25), 32))
	skills_vb.add_child(btn("إغلاق", close_overlays, Color(0.3, 0.2, 0.75), 38))


func upgrade(id: String) -> void:
	if skill(id) >= 5 or int(data["points"]) < 1:
		return
	data["skills"][id] = skill(id) + 1
	data["points"] = int(data["points"]) - 1
	play("win")
	save_game()
	refresh()
	rebuild_skills.call_deferred()


func close_overlays() -> void:
	ui["skills"].visible = false
	ui["gods"].visible = false
	refresh()


func to_menu() -> void:
	save_game()
	go("menu")


func open_gods() -> void:
	ui["gods"].visible = true
	rebuild_gods()


func rebuild_gods() -> void:
	clear_node(gods_vb)
	gods_vb.add_child(lbl("حرب العوالم", 48, Color(1, 0.6, 0.5)))
	var pw := player_power()
	gods_vb.add_child(lbl("قوتك الإلهية: %d" % int(pw), 36, Color(0.7, 0.9, 1)))
	for i in gods.size():
		var g: Dictionary = gods[i]
		var gcol := Color.html(str(g["col"]))
		var card := PanelContainer.new()
		card.add_theme_stylebox_override("panel", mk_style(Color(0.1, 0.08, 0.3, 0.98), 22, gcol))
		gods_vb.add_child(card)
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 14)
		card.add_child(hb)
		var pv := Proxy.new()
		pv.custom_minimum_size = Vector2(210, 200)
		pv.cb = draw_god_preview.bind(i)
		hb.add_child(pv)
		var vb := VBoxContainer.new()
		vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.add_child(vb)
		vb.add_child(lbl(String(g["n"]), 38, gcol))
		var ds := lbl(String(g["desc"]), 26, Color(0.8, 0.85, 1))
		ds.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		ds.custom_minimum_size = Vector2(200, 0)
		vb.add_child(ds)
		var gp: float = g["power"]
		var chance := int(100.0 * pw / (pw + gp))
		vb.add_child(lbl("قوته: %d   |   فرصتك: %d%%" % [int(gp), chance], 28, Color(1, 0.9, 0.6)))
		vb.add_child(btn("أعلن الحرب", start_war.bind(i), Color(0.7, 0.15, 0.2), 34))
	var sp := Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	gods_vb.add_child(sp)
	gods_vb.add_child(btn("إغلاق", close_overlays, Color(0.3, 0.2, 0.75), 38))


func draw_god_preview(ci: Control, gi: int) -> void:
	if gi >= gods.size():
		return
	var g: Dictionary = gods[gi]
	var col := Color.html(str(g["col"]))
	var c := ci.size * 0.5
	ci.draw_rect(Rect2(Vector2.ZERO, ci.size), Color(0.02, 0.02, 0.08, 0.95))
	ci.draw_circle(c, ci.size.x * 0.45, Color(col.r, col.g, col.b, 0.14))
	var arr: Array = g["ents"]
	for e in arr:
		var k: String = e["k"]
		var pos := c + Vector2(float(e["x"]), float(e["y"])) * 0.075
		draw_ent(ci, k, pos, 0.2 * float(e["s"]), tm, float(e["seed"]))


func show_result(text: String) -> void:
	res_lbl.text = text
	ui["result"].visible = true


func close_result() -> void:
	ui["result"].visible = false
	go("world")


# ============================================================
#  القائمة الرئيسية
# ============================================================
func continue_game() -> void:
	if not load_game():
		data = default_data()
		ents = data["ents"]
		gods = data["gods"]
	cam = world_center()
	go("world")


func new_game() -> void:
	data = default_data()
	ents = data["ents"]
	gods = data["gods"]
	cam = Vector2.ZERO
	save_game()
	go("world")


# ============================================================
#  الإدخال في عالم الخلق
# ============================================================
func center_pt() -> Vector2:
	return Vector2(size.x * 0.5, (150.0 + size.y - 440.0) * 0.5)


func w2s(p: Vector2) -> Vector2:
	return (p - cam) * zoom + center_pt()


func s2w(p: Vector2) -> Vector2:
	return (p - center_pt()) / zoom + cam


func pick(sp: Vector2) -> int:
	for i in range(ents.size() - 1, -1, -1):
		var e: Dictionary = ents[i]
		var k: String = e["k"]
		var r: float = maxf(float(RAD[k]) * float(e["s"]) * zoom, 36.0)
		if w2s(Vector2(e["x"], e["y"])).distance_to(sp) <= r:
			return i
	return -1


func _gui_input(ev: InputEvent) -> void:
	if screen != "world":
		return
	if ev is InputEventMouseButton:
		if ev.button_index == MOUSE_BUTTON_LEFT:
			if ev.pressed:
				dragging = true
				moved = false
				press_pos = ev.position
				drag_ent = -1
				if tool == "move":
					drag_ent = pick(ev.position)
			else:
				if dragging and not moved:
					tap(ev.position)
				if dragging and moved and drag_ent >= 0:
					save_game()
				dragging = false
				drag_ent = -1
		elif ev.button_index == MOUSE_BUTTON_WHEEL_UP and ev.pressed:
			zoom_by(1.1)
		elif ev.button_index == MOUSE_BUTTON_WHEEL_DOWN and ev.pressed:
			zoom_by(0.9)
	elif ev is InputEventMouseMotion and dragging:
		if ev.position.distance_to(press_pos) > 14.0:
			moved = true
		if moved:
			if drag_ent >= 0 and drag_ent < ents.size():
				var e: Dictionary = ents[drag_ent]
				e["x"] = float(e["x"]) + ev.relative.x / zoom
				e["y"] = float(e["y"]) + ev.relative.y / zoom
			else:
				cam -= ev.relative / zoom


func tap(sp: Vector2) -> void:
	if tool == "erase":
		var i := pick(sp)
		if i >= 0:
			var e: Dictionary = ents[i]
			burst(Vector2(e["x"], e["y"]), Color(1, 0.5, 0.4), 18)
			ents.remove_at(i)
			play("erase")
			refresh()
			save_game()
	elif tool != "move":
		var wp := s2w(sp)
		ents.append({"k": tool, "x": wp.x, "y": wp.y, "s": place_scale, "seed": randf()})
		sort_ents()
		burst(wp, Color(0.8, 0.9, 1.0), 26)
		play("place")
		var p: float = ITEMS[tool]["p"]
		add_xp(3 + int(p / 10.0))
		refresh()
		save_game()


func burst(wp: Vector2, col: Color, n: int) -> void:
	for i in n:
		parts.append({"p": wp, "v": Vector2.from_angle(randf() * TAU) * randf_range(60.0, 320.0), "l": 1.0, "c": col})
	if parts.size() > 320:
		parts = parts.slice(parts.size() - 320)


func pop_text(t: String, sp: Vector2, col: Color) -> void:
	pops.append({"t": t, "p": sp, "l": 1.0, "c": col})


# ============================================================
#  حرب العوالم
# ============================================================
func start_war(gi: int) -> void:
	war_god = gi
	var g: Dictionary = gods[gi]
	var pw := player_power()
	var gp: float = g["power"]
	var np := clampi(count_life(ents) + 6, 6, 30)
	var ng := clampi(count_life(g["ents"]) + 6, 6, 30)
	var kinds: Array = []
	for e in ents:
		if LIFE.has(e["k"]):
			kinds.append(e["k"])
	if kinds.is_empty():
		kinds.append("human")
	units.clear()
	var w := size.x
	var top_y := 280.0
	var bot_y := size.y - 280.0
	for i in np:
		units.append({"side": 0, "p": Vector2(randf_range(110.0, w - 110.0), randf_range(bot_y - 260.0, bot_y)), "hp": 3.0, "cd": randf(), "k": kinds[i % kinds.size()], "flash": 0.0, "seed": randf()})
	for i in ng:
		units.append({"side": 1, "p": Vector2(randf_range(110.0, w - 110.0), randf_range(top_y, top_y + 260.0)), "hp": 3.0, "cd": randf(), "k": "minion", "flash": 0.0, "seed": randf()})
	fp = clampf(2.0 * pw / (pw + gp), 0.5, 1.6)
	fg = clampf(2.0 * gp / (pw + gp), 0.5, 1.6)
	war_over = false
	war_won = false
	war_t = 0.0
	war_end_t = 0.0
	war_speed = 1.0
	parts.clear()
	go("war")


func toggle_speed() -> void:
	war_speed = 2.5 if war_speed < 2.0 else 1.0


func retreat() -> void:
	go("world")


func alive_count(side: int) -> int:
	var c := 0
	for u in units:
		if int(u["side"]) == side and float(u["hp"]) > 0.0:
			c += 1
	return c


func upd_war(dt: float) -> void:
	if war_over:
		war_end_t -= dt
		if war_end_t <= 0.0:
			start_duel(war_won)
		return
	var d := dt * war_speed
	war_t += d
	var lim_x := size.x - 70.0
	for u in units:
		var hp: float = u["hp"]
		u["flash"] = maxf(0.0, float(u["flash"]) - dt)
		if hp <= 0.0:
			continue
		var side: int = u["side"]
		var up: Vector2 = u["p"]
		var best: Dictionary = {}
		var bd := 1e9
		for v in units:
			if int(v["side"]) != side and float(v["hp"]) > 0.0:
				var dd := up.distance_to(v["p"])
				if dd < bd:
					bd = dd
					best = v
		if best.is_empty():
			continue
		if bd > 56.0:
			var dir: Vector2 = (Vector2(best["p"]) - up).normalized()
			up += dir * 95.0 * d
			up.x = clampf(up.x, 70.0, lim_x)
			u["p"] = up
		else:
			u["cd"] = float(u["cd"]) - d
			if float(u["cd"]) <= 0.0:
				u["cd"] = 0.7
				var mult: float = fp if side == 0 else fg
				best["hp"] = float(best["hp"]) - mult * randf_range(0.7, 1.3)
				best["flash"] = 0.25
				burst(Vector2(best["p"]), Color(1, 0.8, 0.4), 4)
				if randf() < 0.25:
					play("hit")
	var a := alive_count(0)
	var b := alive_count(1)
	war_lbl.text = "جيشك: %d      |      %s: %d" % [a, String(gods[war_god]["n"]), b]
	if a == 0 or b == 0 or war_t > 45.0:
		war_over = true
		war_won = a >= b
		war_end_t = 2.6
		war_lbl.text = "انتصر جيشك! تبدأ مبارزة الآلهة بميزة لك" if war_won else "هُزم جيشك... تبدأ مبارزة الآلهة وأنت متأخر"
		play("big")


# ============================================================
#  مبارزة الآلهة
# ============================================================
func start_duel(adv: bool) -> void:
	var g: Dictionary = gods[war_god]
	var pw := player_power()
	var gp: float = g["power"]
	dpm = 140.0 + float(data["level"]) * 10.0 + sqrt(pw) * 3.0
	dgm = 140.0 + sqrt(gp) * 3.5
	dp = dpm
	dg = dgm
	if adv:
		dg = dgm * 0.75
	else:
		dp = dpm * 0.75
	en = 50.0
	g_en = 40.0
	p_shield = false
	g_shield = false
	turn = "player"
	log_lines.clear()
	pops.clear()
	add_log("بدأت مبارزة الآلهة! دورك الآن.")
	go("duel")
	set_duel_btns(true)


func add_log(t: String) -> void:
	log_lines.append(t)
	while log_lines.size() > 2:
		log_lines.pop_front()
	duel_log.text = "\n".join(log_lines)


func set_duel_btns(on: bool) -> void:
	for b in duel_btns:
		b.disabled = not on


func duel_pos_god() -> Vector2:
	return Vector2(size.x * 0.5, 520.0)


func duel_pos_me() -> Vector2:
	return Vector2(size.x * 0.5, size.y - 760.0)


func upd_duel(dt: float) -> void:
	shake_p = maxf(0.0, shake_p - dt * 2.0)
	shake_g = maxf(0.0, shake_g - dt * 2.0)


func p_act(a: String) -> void:
	if turn != "player":
		return
	var wr := 1.0 + 0.12 * float(skill("wrath"))
	var base := randf_range(16.0, 26.0) + float(data["level"]) * 1.2 + sqrt(player_power()) * 0.25
	var d := 0.0
	match a:
		"atk":
			d = base * wr
			add_log("وجّهت ضربة كونية!")
			play("hit")
		"big":
			if en < 40.0:
				toast("الطاقة غير كافية")
				return
			en -= 40.0
			d = base * 2.1 * wr
			add_log("أطلقت انفجاراً نجمياً هائلاً!")
			play("big")
		"shield":
			p_shield = true
			add_log("رفعت درعاً إلهياً.")
			play("click")
		"heal":
			if en < 30.0:
				toast("الطاقة غير كافية")
				return
			en -= 30.0
			var h := 30.0 + 7.0 * float(skill("wisdom")) + dpm * 0.1
			dp = minf(dpm, dp + h)
			pop_text("+%d" % int(h), duel_pos_me() + Vector2(0, -150), Color(0.5, 1, 0.6))
			add_log("استعدت جزءاً من قوتك.")
			play("heal")
	if d > 0.0:
		if g_shield:
			d *= 0.5
			g_shield = false
		dg -= d
		shake_g = 1.0
		pop_text("-%d" % int(d), duel_pos_god() + Vector2(0, -170), Color(1, 0.8, 0.4))
		burst(duel_pos_god(), Color(1, 0.8, 0.4), 12)
	turn = "wait"
	set_duel_btns(false)
	if dg <= 0.0:
		duel_end(true)
		return
	await get_tree().create_timer(1.0).timeout
	if screen != "duel":
		return
	god_act()


func god_act() -> void:
	var g: Dictionary = gods[war_god]
	var kind: String = g["kind"]
	var gp := sqrt(float(g["power"]))
	g_en = minf(100.0, g_en + 25.0)
	en = minf(100.0, en + 25.0 + 5.0 * float(skill("wisdom")))
	var mv := "atk"
	match kind:
		"verdant":
			if dg < dgm * 0.5 and g_en >= 30.0 and randf() < 0.6:
				mv = "heal"
			elif randf() < 0.2:
				mv = "shield"
		"tyrant":
			if g_en >= 40.0 and randf() < 0.6:
				mv = "big"
		"void":
			var r := randf()
			if r < 0.3:
				mv = "drain"
			elif r < 0.45:
				mv = "curse"
	var gname: String = g["n"]
	var d := 0.0
	match mv:
		"atk":
			d = randf_range(12.0, 20.0) + gp * 0.35
			add_log("%s يهاجمك!" % gname)
		"big":
			g_en -= 40.0
			d = (randf_range(12.0, 20.0) + gp * 0.35) * 2.0
			add_log("%s يطلق ضربة مدمرة!" % gname)
		"heal":
			g_en -= 30.0
			var h := 30.0 + gp * 0.8
			dg = minf(dgm, dg + h)
			pop_text("+%d" % int(h), duel_pos_god() + Vector2(0, -170), Color(0.5, 1, 0.6))
			add_log("%s يداوي نفسه." % gname)
			play("heal")
		"shield":
			g_shield = true
			add_log("%s يتحصّن بدرعه." % gname)
		"drain":
			d = 8.0 + gp * 0.15
			en = maxf(0.0, en - 30.0)
			dg = minf(dgm, dg + d * 0.8)
			add_log("%s يمتص طاقتك!" % gname)
		"curse":
			d = 14.0 + gp * 0.3
			en = maxf(0.0, en - 15.0)
			add_log("%s يلقي عليك لعنة الفراغ!" % gname)
	if d > 0.0:
		if p_shield:
			d *= 0.4
			p_shield = false
		d *= (1.0 - 0.08 * float(skill("shield")))
		dp -= d
		shake_p = 1.0
		pop_text("-%d" % int(d), duel_pos_me() + Vector2(0, -150), Color(1, 0.4, 0.4))
		burst(duel_pos_me(), Color(1, 0.4, 0.4), 12)
		play("big" if mv == "big" else "hit")
	if dp <= 0.0:
		duel_end(false)
		return
	turn = "player"
	set_duel_btns(true)


func duel_end(won: bool) -> void:
	turn = "over"
	set_duel_btns(false)
	await get_tree().create_timer(0.8).timeout
	if won:
		victory()
	else:
		defeat()


func victory() -> void:
	var g: Dictionary = gods[war_god]
	var gain: float = float(g["power"]) * 0.5
	data["bonus"] = float(data["bonus"]) + gain
	var c := world_center()
	var garr: Array = g["ents"]
	for e in garr:
		ents.append({"k": e["k"], "x": c.x + float(e["x"]) * 1.2, "y": c.y + float(e["y"]) * 1.2, "s": e["s"], "seed": e["seed"]})
	sort_ents()
	data["wins"] = int(data["wins"]) + 1
	var old_name: String = g["n"]
	var gi := war_god
	add_xp(150 + int(sqrt(float(g["power"])) * 3.0))
	gods[gi] = make_god(int(g["i"]), int(data["wins"]))
	save_game()
	play("win")
	show_result("انتصرت!\nابتلعت عوالم %s وصار مصيره قوةً لك: +%d قوة إلهية.\nظهر إله أقوى يتحدى عرشك." % [old_name, int(gain)])


func defeat() -> void:
	add_xp(20)
	save_game()
	play("lose")
	show_result("هُزمت في المبارزة...\nلكن عوالمك ومخلوقاتك باقية. ازدد قوة وعد للانتقام.")


# ============================================================
#  التحديث والرسم
# ============================================================
func _process(dt: float) -> void:
	tm += dt
	for p in parts:
		p["p"] = Vector2(p["p"]) + Vector2(p["v"]) * dt
		p["l"] = float(p["l"]) - dt * 1.4
	parts = parts.filter(func(p): return float(p["l"]) > 0.0)
	for q in pops:
		q["p"] = Vector2(q["p"]) + Vector2(0, -50.0 * dt)
		q["l"] = float(q["l"]) - dt * 0.9
	pops = pops.filter(func(q): return float(q["l"]) > 0.0)
	if screen == "war":
		upd_war(dt)
	elif screen == "duel":
		upd_duel(dt)
	queue_redraw()


func ellipse_pts(c: Vector2, rx: float, ry: float, n := 22) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in n:
		var a := float(i) / float(n) * TAU
		pts.append(c + Vector2(cos(a) * rx, sin(a) * ry))
	return pts


func draw_ent(ci: CanvasItem, k: String, p: Vector2, sc: float, t: float, sd: float) -> void:
	var r: float = float(RAD[k]) * sc
	match k:
		"universe":
			for i in 5:
				ci.draw_circle(p, r * (1.0 - float(i) * 0.17), Color(0.35 + 0.08 * i, 0.2, 0.8, 0.10))
			ci.draw_arc(p, r, 0.0, TAU, 64, Color(0.7, 0.5, 1.0, 0.75), 3.0, true)
			for i in 16:
				var a := sd * 7.0 + float(i) * 2.399
				var dist := r * 0.85 * fmod(float(i) * 0.37 + 0.1, 1.0)
				var tw := 0.5 + 0.5 * sin(t * 2.0 + float(i))
				ci.draw_circle(p + Vector2(cos(a), sin(a)) * dist, maxf(1.5, 3.0 * sc), Color(1, 1, 1, 0.3 + 0.5 * tw))
		"galaxy":
			for arm in 2:
				var pts := PackedVector2Array()
				for i in 40:
					var f := float(i) / 39.0
					var a := f * 5.0 + float(arm) * PI + t * 0.3 + sd
					pts.append(p + Vector2(cos(a), sin(a)) * r * f)
				ci.draw_polyline(pts, Color(0.6, 0.75, 1.0, 0.85), maxf(1.5, 5.0 * sc), true)
			ci.draw_circle(p, r * 0.35, Color(1, 0.9, 0.6, 0.15))
			ci.draw_circle(p, r * 0.18, Color(1, 0.95, 0.7, 0.95))
		"solar":
			ci.draw_circle(p, r * 0.4, Color(1, 0.8, 0.2, 0.2))
			ci.draw_circle(p, r * 0.22, Color(1, 0.85, 0.3))
			var pcols := [Color(0.4, 0.7, 1), Color(1, 0.5, 0.4), Color(0.6, 1, 0.6)]
			for i in 3:
				var orr := r * (0.4 + 0.25 * float(i))
				ci.draw_arc(p, orr, 0.0, TAU, 40, Color(1, 1, 1, 0.18), 1.5, true)
				var a := t * (1.2 - 0.3 * float(i)) + sd * 6.0 + float(i) * 2.0
				ci.draw_circle(p + Vector2(cos(a), sin(a)) * orr, r * 0.07, pcols[i])
		"star":
			var pulse := 1.0 + 0.12 * sin(t * 3.0 + sd * 6.0)
			ci.draw_circle(p, r * 1.9 * pulse, Color(1, 0.9, 0.5, 0.08))
			ci.draw_circle(p, r * 1.3 * pulse, Color(1, 0.9, 0.5, 0.18))
			ci.draw_circle(p, r * 0.6, Color(1, 0.97, 0.8))
			ci.draw_line(p - Vector2(r * 1.8, 0), p + Vector2(r * 1.8, 0), Color(1, 1, 0.8, 0.6), 2.0, true)
			ci.draw_line(p - Vector2(0, r * 1.8), p + Vector2(0, r * 1.8), Color(1, 1, 0.8, 0.6), 2.0, true)
		"planet":
			var col := Color.from_hsv(fmod(sd * 2.7, 1.0), 0.55, 0.9)
			if sd > 0.6:
				var rp := PackedVector2Array()
				for i in 41:
					var a := float(i) / 40.0 * TAU
					rp.append(p + Vector2(cos(a) * r * 1.7, sin(a) * r * 0.45))
				ci.draw_polyline(rp, Color(0.9, 0.85, 0.7, 0.6), maxf(1.5, r * 0.1), true)
			ci.draw_circle(p, r, col)
			for i in 3:
				var yy := (-0.5 + 0.5 * float(i)) * r
				var xx := sqrt(maxf(0.0, r * r - yy * yy)) * 0.92
				ci.draw_line(p + Vector2(-xx, yy), p + Vector2(xx, yy), Color(1, 1, 1, 0.16), maxf(1.0, r * 0.12))
			ci.draw_circle(p + Vector2(-r * 0.3, -r * 0.3), r * 0.35, Color(1, 1, 1, 0.22))
		"blackhole":
			for i in 3:
				var pts := PackedVector2Array()
				for j in 41:
					var a := float(j) / 40.0 * TAU
					pts.append(p + Vector2(cos(a) * r * (1.5 + 0.3 * float(i)), sin(a) * r * (0.45 + 0.1 * float(i))))
				ci.draw_polyline(pts, Color(1, 0.5 + 0.15 * float(i), 0.2, 0.6 - 0.15 * float(i)), maxf(1.5, 4.0 * sc), true)
			ci.draw_circle(p, r * 0.85, Color(1, 0.6, 0.2, 0.35))
			ci.draw_circle(p, r * 0.72, Color.BLACK)
			for i in 8:
				var f := fmod(t * 0.3 + float(i) / 8.0, 1.0)
				var a := t + float(i) * 0.785 + f * 4.0
				var dd := r * (2.2 - 1.5 * f)
				ci.draw_circle(p + Vector2(cos(a) * dd, sin(a) * dd * 0.45), maxf(1.0, r * 0.06), Color(1, 0.8, 0.5, 0.8 * (1.0 - f)))
		"human":
			var skin := Color(1, 0.85, 0.7)
			var shirt := Color.from_hsv(fmod(sd * 3.0, 1.0), 0.55, 0.95)
			var sway := sin(t * 3.0 + sd * 10.0) * 0.18
			ci.draw_circle(p, r * 1.5, Color(1, 1, 1, 0.05))
			ci.draw_circle(p + Vector2(0, -r * 0.6), r * 0.36, skin)
			ci.draw_line(p + Vector2(0, -r * 0.25), p + Vector2(0, r * 0.3), shirt, r * 0.4)
			ci.draw_line(p + Vector2(0, -r * 0.15), p + Vector2(-r * 0.55, r * (0.2 + sway)), skin, r * 0.14)
			ci.draw_line(p + Vector2(0, -r * 0.15), p + Vector2(r * 0.55, r * (0.2 - sway)), skin, r * 0.14)
			ci.draw_line(p + Vector2(-r * 0.12, r * 0.3), p + Vector2(-r * 0.25, r * 0.9), Color(0.3, 0.3, 0.6), r * 0.16)
			ci.draw_line(p + Vector2(r * 0.12, r * 0.3), p + Vector2(r * 0.25, r * 0.9), Color(0.3, 0.3, 0.6), r * 0.16)
		"animal":
			var col := Color.from_hsv(0.06 + fmod(sd, 0.1), 0.55, 0.75)
			var lg := sin(t * 5.0 + sd * 9.0) * r * 0.18
			ci.draw_colored_polygon(ellipse_pts(p, r * 0.9, r * 0.5, 20), col)
			for i in 4:
				var lx := (-0.55 + 0.37 * float(i)) * r
				var dz: float = lg if i % 2 == 0 else -lg
				ci.draw_line(p + Vector2(lx, r * 0.3), p + Vector2(lx + dz, r * 0.8), col.darkened(0.3), r * 0.16)
			ci.draw_circle(p + Vector2(r * 0.95, -r * 0.25), r * 0.32, col.lightened(0.1))
			ci.draw_circle(p + Vector2(r * 1.05, -r * 0.32), r * 0.06, Color.BLACK)
			ci.draw_line(p + Vector2(-r * 0.85, -r * 0.1), p + Vector2(-r * 1.25, -r * 0.45 + lg * 0.3), col, r * 0.12)
		"plant":
			var sw := sin(t * 1.5 + sd * 8.0) * r * 0.25
			var tip := p + Vector2(sw, -r * 1.0)
			var mid := p + Vector2(sw * 0.4, -r * 0.3)
			ci.draw_line(p + Vector2(0, r * 0.7), tip, Color(0.2, 0.7, 0.3), maxf(1.5, r * 0.14))
			ci.draw_colored_polygon(PackedVector2Array([mid, mid + Vector2(-r * 0.7, -r * 0.2), mid + Vector2(-r * 0.15, -r * 0.45)]), Color(0.3, 0.85, 0.4))
			ci.draw_colored_polygon(PackedVector2Array([mid, mid + Vector2(r * 0.7, -r * 0.1), mid + Vector2(r * 0.15, -r * 0.4)]), Color(0.25, 0.75, 0.35))
			for i in 5:
				var a := float(i) * TAU / 5.0 + t * 0.3
				ci.draw_circle(tip + Vector2(cos(a), sin(a)) * r * 0.25, r * 0.17, Color(1, 0.5, 0.7))
			ci.draw_circle(tip, r * 0.14, Color(1, 0.9, 0.3))
		"fish":
			var col := Color.from_hsv(fmod(0.05 + sd * 0.6, 1.0), 0.7, 1.0)
			var wag := sin(t * 6.0 + sd * 5.0) * r * 0.2
			ci.draw_colored_polygon(ellipse_pts(p, r * 0.9, r * 0.5, 20), col)
			ci.draw_colored_polygon(PackedVector2Array([p + Vector2(-r * 0.7, 0), p + Vector2(-r * 1.35, -r * 0.5 + wag), p + Vector2(-r * 1.35, r * 0.5 + wag)]), col.darkened(0.15))
			ci.draw_circle(p + Vector2(r * 0.5, -r * 0.1), r * 0.14, Color.WHITE)
			ci.draw_circle(p + Vector2(r * 0.54, -r * 0.1), r * 0.07, Color.BLACK)
			var bf := fmod(t * 0.6 + sd, 1.0)
			ci.draw_arc(p + Vector2(r * (1.0 + bf * 0.3), -r * bf * 1.2), r * 0.1, 0.0, TAU, 8, Color(0.8, 0.95, 1, 1.0 - bf), 1.5)
		"water":
			ci.draw_circle(p + Vector2(0, r * 0.2), r * 0.7, Color(0.25, 0.6, 1.0))
			ci.draw_colored_polygon(PackedVector2Array([p + Vector2(0, -r * 1.2), p + Vector2(-r * 0.66, r * 0.05), p + Vector2(r * 0.66, r * 0.05)]), Color(0.25, 0.6, 1.0))
			ci.draw_circle(p + Vector2(-r * 0.25, r * 0.05), r * 0.17, Color(1, 1, 1, 0.55))
		"earth":
			var pts := PackedVector2Array()
			for i in 7:
				var a := float(i) * TAU / 7.0
				var rr := r * (0.85 + 0.2 * sin(sd * 20.0 + float(i) * 2.0))
				pts.append(p + Vector2(cos(a), sin(a)) * rr)
			ci.draw_colored_polygon(pts, Color(0.5, 0.34, 0.2))
			ci.draw_arc(p, r * 0.7, PI * 1.1, PI * 1.9, 12, Color(0.3, 0.75, 0.3), maxf(2.0, r * 0.25))
		"fire":
			var f := sin(t * 12.0 + sd * 9.0) * r * 0.12
			ci.draw_circle(p, r * 1.5, Color(1, 0.5, 0.1, 0.12))
			ci.draw_colored_polygon(PackedVector2Array([p + Vector2(0, -r * 1.3 + f), p + Vector2(-r * 0.7, r * 0.2), p + Vector2(0, r * 0.7), p + Vector2(r * 0.7, r * 0.2)]), Color(1, 0.4, 0.1))
			ci.draw_colored_polygon(PackedVector2Array([p + Vector2(0, -r * 0.6 - f), p + Vector2(-r * 0.35, r * 0.2), p + Vector2(0, r * 0.5), p + Vector2(r * 0.35, r * 0.2)]), Color(1, 0.9, 0.3))
		"air":
			for i in 3:
				var yy := (float(i) - 1.0) * r * 0.5
				var off := sin(t * 2.0 + float(i) + sd * 6.0) * r * 0.15
				ci.draw_arc(p + Vector2(off, yy), r * 0.5, PI * 0.1, PI * 1.1, 14, Color(0.85, 0.95, 1, 0.85), maxf(1.5, r * 0.1), true)
		"light":
			ci.draw_circle(p, r * 1.6, Color(1, 0.95, 0.5, 0.12))
			for i in 8:
				var a := float(i) * TAU / 8.0 + t * 0.6
				ci.draw_line(p + Vector2(cos(a), sin(a)) * r * 0.5, p + Vector2(cos(a), sin(a)) * r * 1.3, Color(1, 0.95, 0.6, 0.8), maxf(1.5, r * 0.08))
			ci.draw_circle(p, r * 0.5, Color(1, 1, 0.85))
		"minion":
			var gc := neb_col
			ci.draw_circle(p, r * 1.7, Color(gc.r, gc.g, gc.b, 0.18))
			ci.draw_circle(p, r, gc.darkened(0.2))
			ci.draw_colored_polygon(PackedVector2Array([p + Vector2(-r * 0.7, -r * 0.5), p + Vector2(-r * 0.4, -r * 1.3), p + Vector2(-r * 0.1, -r * 0.7)]), gc)
			ci.draw_colored_polygon(PackedVector2Array([p + Vector2(r * 0.7, -r * 0.5), p + Vector2(r * 0.4, -r * 1.3), p + Vector2(r * 0.1, -r * 0.7)]), gc)
			ci.draw_circle(p + Vector2(-r * 0.35, -r * 0.1), r * 0.2, Color.WHITE)
			ci.draw_circle(p + Vector2(r * 0.35, -r * 0.1), r * 0.2, Color.WHITE)
			ci.draw_circle(p + Vector2(-r * 0.35, -r * 0.1), r * 0.09, Color.BLACK)
			ci.draw_circle(p + Vector2(r * 0.35, -r * 0.1), r * 0.09, Color.BLACK)


func draw_background() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.02, 0.015, 0.09))
	var nc := neb_col
	for i in 3:
		var c := Vector2(size.x * (0.2 + 0.3 * float(i)), size.y * (0.3 + 0.2 * float(i))) - cam * 0.04 * float(i + 1)
		var base := (360.0 + 90.0 * float(i)) * (1.0 + 0.04 * sin(tm * 0.4 + float(i)))
		var col: Color = nc if i == 0 else (Color(0.2, 0.4, 0.9) if i == 1 else Color(0.8, 0.25, 0.6))
		if screen == "war" or screen == "duel":
			col = nc.lerp(col, 0.25 * float(i))
		for j in 5:
			draw_circle(c, base * (1.0 - float(j) * 0.18), Color(col.r, col.g, col.b, 0.035))
	for s in stars:
		var d: float = s.z
		var x := fposmod(s.x * size.x - cam.x * d * 0.2, size.x)
		var y := fposmod(s.y * size.y - cam.y * d * 0.2, size.y)
		var tw := 0.5 + 0.5 * sin(tm * (1.0 + d * 2.0) + s.x * 40.0)
		draw_circle(Vector2(x, y), 1.0 + d * 1.8, Color(1, 1, 1, 0.25 + 0.6 * tw * d))


func _draw() -> void:
	draw_background()
	match screen:
		"menu":
			draw_menu()
		"world":
			draw_world()
		"war":
			draw_war()
		"duel":
			draw_duel()
	draw_particles()
	for q in pops:
		var al: float = clampf(float(q["l"]), 0.0, 1.0)
		var qc: Color = q["c"]
		draw_string(fnt, Vector2(q["p"]) - Vector2(100, 0), String(q["t"]), HORIZONTAL_ALIGNMENT_CENTER, 200, 54, Color(qc.r, qc.g, qc.b, al))


func draw_particles() -> void:
	for p in parts:
		var pos: Vector2 = p["p"]
		if screen == "world":
			pos = w2s(pos)
		var c: Color = p["c"]
		var l: float = p["l"]
		draw_circle(pos, 6.0 * l + 1.0, Color(c.r, c.g, c.b, clampf(l, 0.0, 1.0)))


func draw_menu() -> void:
	var cx := size.x * 0.5
	draw_ent(self, "galaxy", Vector2(cx, size.y * 0.3), 2.4, tm, 0.2)
	draw_string(fnt, Vector2(4, size.y * 0.3 + 6), "إله الخلق", HORIZONTAL_ALIGNMENT_CENTER, size.x, 150, Color(0.5, 0.3, 1.0, 0.45))
	draw_string(fnt, Vector2(0, size.y * 0.3), "إله الخلق", HORIZONTAL_ALIGNMENT_CENTER, size.x, 150, Color(1, 0.92, 0.65))
	draw_string(fnt, Vector2(0, size.y * 0.3 + 90), "OmniForge", HORIZONTAL_ALIGNMENT_CENTER, size.x, 54, Color(0.7, 0.85, 1.0))
	draw_string(fnt, Vector2(0, size.y * 0.5), "كن الإله المطلق · اخلق الأكوان · اهزم الآلهة", HORIZONTAL_ALIGNMENT_CENTER, size.x, 36, Color(0.85, 0.85, 1.0))


func draw_world() -> void:
	for e in ents:
		var k: String = e["k"]
		var sc: float = e["s"]
		var sd: float = e["seed"]
		var p := Vector2(e["x"], e["y"])
		if LIFE.has(k):
			p += Vector2(sin(tm * 0.7 + sd * 10.0), cos(tm * 0.5 + sd * 7.0)) * 8.0
		var sp := w2s(p)
		var rr: float = float(RAD[k]) * sc * zoom * 2.0
		if sp.x < -rr or sp.x > size.x + rr or sp.y < -rr or sp.y > size.y + rr:
			continue
		draw_ent(self, k, sp, sc * zoom, tm, sd)
	if tool == "erase" or tool == "move":
		pass
	var o := w2s(Vector2.ZERO)
	draw_arc(o, 10.0 * zoom + 4.0, 0.0, TAU, 20, Color(1, 1, 1, 0.12), 2.0)


func draw_war() -> void:
	var y0 := 250.0
	var y1 := size.y - 230.0
	draw_line(Vector2(40, (y0 + y1) * 0.5), Vector2(size.x - 40, (y0 + y1) * 0.5), Color(1, 1, 1, 0.08), 3.0)
	for u in units:
		var hp: float = u["hp"]
		if hp <= 0.0:
			continue
		var p: Vector2 = u["p"]
		var k: String = u["k"]
		draw_ent(self, k, p, 1.5, tm, float(u["seed"]))
		if float(u["flash"]) > 0.0:
			draw_arc(p, 36.0, 0.0, TAU, 20, Color(1, 1, 1, float(u["flash"]) * 3.0), 4.0)
		var bw := 46.0
		draw_rect(Rect2(p + Vector2(-bw * 0.5, -48), Vector2(bw, 6)), Color(0, 0, 0, 0.6))
		var hc: Color = Color(0.4, 1, 0.5) if int(u["side"]) == 0 else Color(1, 0.4, 0.4)
		draw_rect(Rect2(p + Vector2(-bw * 0.5, -48), Vector2(bw * clampf(hp / 3.0, 0.0, 1.0), 6)), hc)


func draw_creator(c: Vector2) -> void:
	var pulse := 1.0 + 0.05 * sin(tm * 3.0)
	for i in 5:
		draw_circle(c, (120.0 + float(i) * 22.0) * pulse, Color(0.4, 0.7, 1.0, 0.07))
	var hex := PackedVector2Array()
	var hex2 := PackedVector2Array()
	for i in 6:
		var a := float(i) * TAU / 6.0 + tm * 0.5
		hex.append(c + Vector2(cos(a), sin(a)) * 95.0)
		var b := float(i) * TAU / 6.0 - tm * 0.8
		hex2.append(c + Vector2(cos(b), sin(b)) * 58.0)
	draw_colored_polygon(hex, Color(0.2, 0.35, 0.85, 0.9))
	hex.append(hex[0])
	draw_polyline(hex, Color(0.7, 0.9, 1.0), 4.0, true)
	draw_colored_polygon(hex2, Color(0.7, 0.9, 1.0, 0.95))
	draw_circle(c, 26.0, Color.WHITE)
	for i in 3:
		var a := tm * 1.4 + float(i) * TAU / 3.0
		draw_circle(c + Vector2(cos(a), sin(a) * 0.5) * 140.0, 8.0, Color(1, 0.9, 0.5))


func draw_god(c: Vector2, col: Color, kind: String) -> void:
	var pulse := 1.0 + 0.05 * sin(tm * 2.5)
	for i in 5:
		draw_circle(c, (110.0 + float(i) * 24.0) * pulse, Color(col.r, col.g, col.b, 0.08))
	draw_circle(c, 95.0, col.darkened(0.35))
	draw_circle(c, 80.0, col.darkened(0.15))
	draw_arc(c, 108.0, tm, tm + PI * 1.4, 30, col.lightened(0.3), 6.0, true)
	draw_arc(c, 125.0, -tm * 0.7, -tm * 0.7 + PI * 0.9, 24, col, 4.0, true)
	match kind:
		"tyrant":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-70, -50), c + Vector2(-45, -150), c + Vector2(-20, -70)]), col.lightened(0.2))
			draw_colored_polygon(PackedVector2Array([c + Vector2(70, -50), c + Vector2(45, -150), c + Vector2(20, -70)]), col.lightened(0.2))
		"verdant":
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -90), c + Vector2(-50, -150), c + Vector2(-10, -140)]), Color(0.5, 1, 0.6))
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, -90), c + Vector2(50, -150), c + Vector2(10, -140)]), Color(0.5, 1, 0.6))
		_:
			draw_arc(c + Vector2(0, -110), 40.0, PI, TAU, 16, col.lightened(0.4), 6.0, true)
	draw_circle(c + Vector2(-32, -10), 16.0, Color.WHITE)
	draw_circle(c + Vector2(32, -10), 16.0, Color.WHITE)
	draw_circle(c + Vector2(-32, -10), 7.0, Color.BLACK)
	draw_circle(c + Vector2(32, -10), 7.0, Color.BLACK)
	draw_arc(c + Vector2(0, 28), 28.0, 0.2, PI - 0.2, 12, Color(0, 0, 0, 0.8), 5.0, true)


func draw_bar(r: Rect2, v: float, mx: float, col: Color) -> void:
	draw_rect(r, Color(0, 0, 0, 0.6))
	var f := clampf(v / maxf(mx, 1.0), 0.0, 1.0)
	draw_rect(Rect2(r.position, Vector2(r.size.x * f, r.size.y)), col)
	draw_rect(r, Color(1, 1, 1, 0.35), false, 2.0)


func draw_duel() -> void:
	var g: Dictionary = gods[war_god]
	var gc := Color.html(str(g["col"]))
	var gp := duel_pos_god() + Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake_g * 16.0
	var mp := duel_pos_me() + Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake_p * 16.0
	draw_god(gp, gc, String(g["kind"]))
	draw_creator(mp)
	var bw := size.x - 160.0
	draw_string(fnt, Vector2(0, 150), String(g["n"]), HORIZONTAL_ALIGNMENT_CENTER, size.x, 46, gc.lightened(0.2))
	draw_bar(Rect2(80, 175, bw, 30), dg, dgm, gc)
	draw_string(fnt, Vector2(0, mp.y + 175), "الخالق المطلق", HORIZONTAL_ALIGNMENT_CENTER, size.x, 40, Color(0.8, 0.95, 1))
	draw_bar(Rect2(80, mp.y + 190, bw, 30), dp, dpm, Color(0.4, 0.85, 1.0))
	draw_bar(Rect2(80, mp.y + 230, bw, 18), en, 100.0, Color(1, 0.85, 0.3))
	if p_shield:
		draw_arc(mp, 150.0, 0.0, TAU, 40, Color(0.5, 0.8, 1.0, 0.8), 8.0, true)
	if g_shield:
		draw_arc(gp, 150.0, 0.0, TAU, 40, Color(0.8, 0.9, 1.0, 0.8), 8.0, true)
